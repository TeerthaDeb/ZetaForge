package main

import (
	_ "embed"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"maps"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

var mode string

//go:embed entrypoint.py
var entrypoint []byte

var current_directory = ""

var TMPPATH = "tmp"

var historySubfolder = ""

var docker_image_name = ""

func execCommand(cmd string, dir string, id string, args Dict, historySubfolder string) error {

	var command *exec.Cmd
	var commandArgs []string

	// Build the command arguments from the args
	for key, value := range args {
		commandArgs = append(commandArgs, key+"="+value)
	}
	fmt.Println("Dir:", dir)
	fmt.Println("PASSING ARGS:", commandArgs)
	command = exec.Command("python", filepath.Join(dir, "entrypoint.py"), dir, historySubfolder, mode)

	// Append commandArgs to the command
	command.Args = append(command.Args, commandArgs...)

	// Set environment variables
	command.Env = os.Environ()
	command.Env = append(command.Env, "_blockid_="+id)

	// Execute the command and capture output
	output, err := command.CombinedOutput()
	log.Println("Output: ", string(output))
	return err
}

type Dict map[string]string
type Execution func(args Dict) (Dict, error)

type Message struct {
	Dict Dict
	Err  error
}

type Task struct {
	Name   string
	Exec   func(args Dict) error
	MapIn  Dict
	MapOut Dict
	In     []<-chan Message
	Out    []chan<- Message
}

func (t *Task) Execute(args Dict) (Dict, error) {
	inputs := make(Dict)
	for key, value := range t.MapIn {
		inputs[value] = args[key]
	}

	outputs := make(Dict)
	err := t.Exec(inputs)
	if err != nil {
		return outputs, err
	}

	for key, value := range t.MapOut {

		data, err := os.ReadFile(filepath.Join(TMPPATH, t.Name, value) + ".txt") // wants to read from the block floder

		if err != nil {
			println("From line:199. value: ", value, ", TMPPATH:", TMPPATH)
			data, err = os.ReadFile(filepath.Join(historySubfolder, value) + ".txt")
		}
		// fmt.Println("## Trying to readfile for the task:", t.Name, ". And the file to read: ", data, ", error while reading: ", err)
		if err != nil {
			return outputs, err
		}

		outputs[key] = string(data)

		os.Remove(filepath.Join(TMPPATH, value) + ".txt")
	}

	return outputs, nil
}

type Param struct {
	Name  string
	Value string
	Out   []chan<- Message
}

func deployTask(pipeline *Pipeline, historySubfolder string, argsKeyVal []ArgsKeyVal) (Execution, func()) {
	tasks := make(map[string]*Task)
	inputs := make(map[string]*Param)
	outputs := make(map[string]<-chan Message)

	for name, block := range pipeline.Pipeline { // basically this funciton maps key value for parameters, writes entrypoint.py and stores every task in task dictionary.
		name := name
		block := block
		if block.Action.Container.Image != "" {
			tasks[name] = &Task{Name: name, Exec: func(args Dict) error {
				log.Println("Error from 110: ", args)
				return nil
			}}
			if block.Action.Command.Dir == "" {
				os.WriteFile(filepath.Join(TMPPATH, name, "entrypoint.py"), entrypoint, 0644)

			} else {
				os.WriteFile(filepath.Join(block.Action.Command.Dir, "entrypoint.py"), entrypoint, 0644)
			}

			tasks[name] = &Task{Name: name, Exec: func(args Dict) error { // without that entrypoint won't run
				return execCommand(block.Action.Command.Exec, filepath.Join(TMPPATH, name), block.Information.Id, args, historySubfolder)
			}}
		} else if len(block.Action.Parameters) > 0 { // importatnt for passing parameters
			// Iterate over block parameters
			for key, value := range block.Action.Parameters {
				finalValue := value.Value // Default to the original value

				// Search for a matching key in argsKeyVal
				for i := range argsKeyVal {
					if argsKeyVal[i].Key == key {
						// If a match is found, replace the final value with the argument value
						finalValue = argsKeyVal[i].Value

						// Mark this key-value pair as used
						argsKeyVal[i].Key = "-1"
						argsKeyVal[i].Value = "-1"
						break // Stop searching after the first match
					}
				}

				// Store the final parameter in the inputs map
				inputs[name] = &Param{Name: key, Value: finalValue}
				fmt.Println("Key:", key, ", Final Value:", finalValue)
			}
			fmt.Println("inputs:", inputs)
		} else if block.Action.Command.Exec != "" {
			if block.Action.Command.Dir == "" {
				os.WriteFile("entrypoint.py", entrypoint, 0644)
			} else {
				os.WriteFile(filepath.Join(block.Action.Command.Dir, "entrypoint.py"), entrypoint, 0644)
			}
			tasks[name] = &Task{Name: name, Exec: func(args Dict) error {
				return execCommand(block.Action.Command.Exec, block.Action.Command.Dir, block.Information.Id, args, historySubfolder)
			}}
		} else {
			log.Fatal("Unknown block")
		}
	}
	for name, block := range pipeline.Pipeline { // so this blocks extracts inputs and outputs for each block if they are to be executed.
		if block.Action.Container.Image != "" ||
			block.Action.Command.Exec != "" {
			task := tasks[name]
			task.MapIn = make(Dict)
			task.MapOut = make(Dict)
			for label, input := range block.Inputs { // I am assuming it takes the input parameters
				for _, connection := range input.Connections {
					pipe := make(chan Message, 1)
					task.In = append(task.In, pipe)
					task.MapIn[connection.Block+connection.Variable] = label
					if parent, ok := tasks[connection.Block]; ok {
						parent.Out = append(parent.Out, pipe)
					} else if parent, ok := inputs[connection.Block]; ok {
						parent.Out = append(parent.Out, pipe)
					} else {
						log.Fatal("Unknown connection")
					}
				}
			}
			for label, output := range block.Outputs { // I am assuming it takes the output parameters
				if len(output.Connections) == 0 {
					pipe := make(chan Message, 1)
					outputs[name] = pipe
					task.Out = append(task.Out, pipe)
				} else {
					task.MapOut[name+label] = block.Information.Id
					// fmt.Println("block.information.id:", block.Information.Id, " , Label: ", label)
				}
			}
		}
	}
	for _, task := range tasks {
		go runTask(task)
	}

	execution := func(args Dict) (Dict, error) {
		for name, input := range inputs {
			dict := make(Dict)
			dict[name+input.Name] = input.Value
			for i := 0; i < len(input.Out); i++ {
				input.Out[i] <- Message{Dict: dict}
			}
		}

		results := make(Dict)
		for _, output := range outputs {
			o := <-output
			if o.Err != nil {
				return results, o.Err
			}
			maps.Copy(results, o.Dict)
		}

		return results, nil
	}
	release := func() {
		for _, input := range inputs {
			for i := 0; i < len(input.Out); i++ {
				close(input.Out[i])
			}
		}
	}

	return execution, release
}

func runTask(task *Task) {
	args := make(Dict, len(task.In))

	for {
		var executionError error // initially (0x0 , 0x0)
		for i := 0; i < len(task.In); i++ {
			// fmt.Print("\nin run task for task: ", task.Name, "\tCurrent Task.in: ", task.In[i])
			arg, ok := <-task.In[i]
			// fmt.Println("\t>>ARG , OK: ", arg, ok)
			if !ok {
				for _, next := range task.Out {
					close(next)
				}
				return
			}
			maps.Copy(args, arg.Dict)

			if arg.Err != nil {
				// fmt.Println(">>>>>>>>>ERROR found in : ", task.Name, " , and the error is: ", arg.Err)
				executionError = arg.Err
			}
		}

		if executionError != nil {
			for _, next := range task.Out {
				next <- Message{Err: executionError}
			}

			continue
		}

		dict, err := task.Execute(args)
		// fmt.Println("Executed the task: ", task.Name)

		if err != nil {
			err = fmt.Errorf("\n\ntask %s: %w", task.Name, err)
		}

		message := Message{Dict: dict, Err: err}

		for _, next := range task.Out {
			next <- message
		}
	}
}

func runLocalPipeline(pipeline Pipeline, pipelinePath string, argsKeyVal []ArgsKeyVal) {

	// Create the history subfolder using the current timestamp
	historyDir := filepath.Join(pipelinePath, "history")
	timestamp := time.Now().Format("2006-01-02_15-04-05")
	current_directory, err := os.Getwd()
	if err != nil {
		log.Fatal(err)
	}
	historySubfolder = filepath.Join(current_directory, historyDir, timestamp)
	os.MkdirAll(historySubfolder, os.ModePerm)

	// if there is any file in the values, copy it in history subfolder.
	for _, arg := range argsKeyVal {
		if arg.Key == "path" { // could be other KEY--------- CHECK LATER.
			src := filepath.Clean(arg.Value)
			dest := filepath.Join(historySubfolder, filepath.Base(arg.Value))
			fmt.Println("HISTORY SUBFOLDER:", historySubfolder, " , FILE PATH: ", dest)
			input, err := os.ReadFile(src)
			if err != nil {
				log.Fatal(err)
			}
			if err := os.WriteFile(dest, input, 0644); err != nil {
				log.Fatal(err)
			}
			log.Println("Moved file to", dest)
		}
	}

	execution, release := deployTask(&pipeline, historySubfolder, argsKeyVal)

	result, err := execution(make(Dict))
	if err != nil {
		log.Println("Error from line 481:", err)
	} else {
		log.Println("COMPLETED:", result)
	}

	release()
}

type ArgsKeyVal struct {
	Key   string
	Value string
}

func main() {

	pipelineName := os.Args[2]
	pipelinePath := filepath.Join(".", pipelineName)

	data, err := os.ReadFile(filepath.Join(pipelinePath, "pipeline.json"))
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println("pipelinePath:", pipelinePath)
	var pipeline Pipeline
	err = json.Unmarshal(data, &pipeline)
	if err != nil {
		log.Fatal(err)
	}

	current_directory, err := os.Getwd()
	if err != nil {
		log.Fatal(err)
	}

	TMPPATH = filepath.Join(current_directory, pipelinePath)

	flag.StringVar(&mode, "mode", "uv", "Execution mode: uv, no-uv, docker")
	flag.Parse()

	if len(os.Args) < 3 {
		log.Fatal("Pipeline name or path must be provided as an argument.")
	}

	var argsKeyVal []ArgsKeyVal // store the parameters passed by arguments.

	for _, arg := range os.Args[3:] {
		parts := strings.SplitN(arg, ":", 2)
		if len(parts) == 2 {
			argsKeyVal = append(argsKeyVal, ArgsKeyVal{
				Key:   parts[0],
				Value: parts[1],
			})
		}
	}

	fmt.Println("PARSED ARGUMENT: ", argsKeyVal, " AND GOT ARGUMENT: ", os.Args[3:]) // print the key value arguements.

	runLocalPipeline(pipeline, pipelinePath, argsKeyVal)
}
